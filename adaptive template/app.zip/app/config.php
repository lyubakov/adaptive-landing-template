<?php

// Настройки для MY site

// Настройки Email
$site['from_name'] = 'Илья Некорыстнов (не отвечать)'; // from (от) имя
$site['from_email'] = 'inekorystnov@gmail.com'; // from (от) email адрес

// На всякий случай указываем настройки
// для дополнительного (внешнего) SMTP сервера.
$site['smtp_mode'] = 'disabled'; // enabled or disabled (включен или выключен)
$site['smtp_host'] = null;
$site['smtp_port'] = null;
$site['smtp_username'] = null;
$site['smtp_password'] = null;

?>