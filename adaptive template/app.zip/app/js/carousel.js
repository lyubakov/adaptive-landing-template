$(document).ready(function(){
  $('.carousel').slick({
  	dots: true,
    arrows: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  });
  $('.options').slick({
  	dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        initialSlide: 3,
        infinite: true,
        centerMode: true,
        centerPadding: 0
      }
    },
    {
      breakpoint: 760,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        initialSlide: 2,
        appendArrows: ('.section_options')
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
  });
});
$('.carousel').on('swipe', function(event, slick, direction){
  $pt = $('.slick-active .button-cta_firstscreen').position().top + parseInt($('.slick-active  .item__header_firstscreen').css('margin-bottom')) + parseInt($('.slick-active  .item__description_firstscreen').css('margin-bottom')) + $('.slick-active .button-cta_firstscreen').outerHeight(true) + 'px';
  $('.slick-dots').css('top', $pt);
});
$('.carousel').on('afterChange', function(){
  $pt = $('.slick-active .button-cta_firstscreen').position().top + parseInt($('.slick-active  .item__header_firstscreen').css('margin-bottom')) + parseInt($('.slick-active  .item__description_firstscreen').css('margin-bottom')) + $('.slick-active .button-cta_firstscreen').outerHeight(true) + 'px';
  $('.slick-dots').css('top', $pt);
});
$(document).ready(function() {
  $pt = $('.slick-active .button-cta_firstscreen').position().top + parseInt($('.slick-active  .item__header_firstscreen').css('margin-bottom')) + parseInt($('.slick-active  .item__description_firstscreen').css('margin-bottom')) + $('.slick-active .button-cta_firstscreen').outerHeight(true) + 'px';
  $('.slick-dots').css('top', $pt);
});
$(window).resize(function() {
  $newpt = $('.slick-active .button-cta_firstscreen').position().top + parseInt($('.slick-active  .item__header_firstscreen').css('margin-bottom')) + parseInt($('.slick-active  .item__description_firstscreen').css('margin-bottom')) + $('.slick-active .button-cta_firstscreen').outerHeight(true) + 'px';
  $('.slick-dots').css('top', $newpt);
});
$( window ).on( "orientationchange", function( event ) {
  $orpt = $('.slick-active .button-cta_firstscreen').position().top + parseInt($('.slick-active  .item__header_firstscreen').css('margin-bottom')) + parseInt($('.slick-active  .item__description_firstscreen').css('margin-bottom')) + $('.slick-active .button-cta_firstscreen').outerHeight(true) + 'px';
  $('.slick-dots').css('top', $orpt);
});